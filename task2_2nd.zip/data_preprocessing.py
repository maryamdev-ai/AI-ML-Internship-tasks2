# data_preprocessing.py
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

def load_and_preprocess_data():
    # 1. Data Loading
    data = pd.read_csv('telco_churn.csv')
    
    # 2. Basic Cleaning
    data = data.drop('customerID', axis=1)  # Remove unique identifier
    data['TotalCharges'] = pd.to_numeric(data['TotalCharges'], errors='coerce')
    data['TotalCharges'] = data['TotalCharges'].fillna(0)  # Fill missing values
    
    # 3. Target Variable Preparation
    data['Churn'] = data['Churn'].map({'Yes': 1, 'No': 0})
    
    # 4. Feature-Target Split
    X = data.drop('Churn', axis=1)
    y = data['Churn']
    
    # 5. Train-Test Split (80-20)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, 
        test_size=0.2, 
        random_state=42, 
        stratify=y
    )
    
    # 6. Save Processed Data
    X_train.to_csv('X_train.csv', index=False)
    X_test.to_csv('X_test.csv', index=False)
    y_train.to_csv('y_train.csv', index=False)
    y_test.to_csv('y_test.csv', index=False)
    
    return X_train, X_test, y_train, y_test

if __name__ == '__main__':
    print("Data preprocessing started...")
    X_train, X_test, y_train, y_test = load_and_preprocess_data()
    print("Data preprocessing completed!")
    print(f"Training set shape: {X_train.shape}")
    print(f"Test set shape: {X_test.shape}")