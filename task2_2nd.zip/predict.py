# predict.py
import pandas as pd
from joblib import load

# 1. Model load karein
model = load('customer_churn_model.joblib')

# 2. Sample input data (aap ise replace kar sakte hain real data se)
sample_data = {
    'tenure': [12],
    'MonthlyCharges': [79.9],
    'TotalCharges': [958.8],
    'gender': ['Female'],
    'SeniorCitizen': [0],
    'Partner': ['Yes'],
    'Dependents': ['No'],
    'PhoneService': ['Yes'],
    'MultipleLines': ['No'],
    'InternetService': ['DSL'],
    'OnlineSecurity': ['No'],
    'OnlineBackup': ['Yes'],
    'DeviceProtection': ['No'],
    'TechSupport': ['No'],
    'StreamingTV': ['No'],
    'StreamingMovies': ['No'],
    'Contract': ['Month-to-month'],
    'PaperlessBilling': ['Yes'],
    'PaymentMethod': ['Electronic check']
}

# 3. DataFrame banayein
input_df = pd.DataFrame(sample_data)

# 4. Prediction karein
prediction = model.predict(input_df)
prediction_proba = model.predict_proba(input_df)

# 5. Results show karein
print("\nPrediction Results:")
print(f"Churn Prediction: {'Yes' if prediction[0] == 1 else 'No'}")
print(f"Confidence: [No: {prediction_proba[0][0]:.2%}, Yes: {prediction_proba[0][1]:.2%}]")

# 6. Feature importance (Random Forest ke liye)
if hasattr(model.named_steps['classifier'], 'feature_importances_'):
    print("\nFeature Importances:")
    features = model.named_steps['preprocessor'].get_feature_names_out()
    importances = model.named_steps['classifier'].feature_importances_
    for feature, importance in zip(features, importances):
        print(f"{feature}: {importance:.4f}")